use strict;
use warnings;
package Bundle::Camelcade;

# ABSTRACT: Bundle of modules used by Perl5 plugin for IntelliJ IDEs

our $VERSION = '0.001';

1;
